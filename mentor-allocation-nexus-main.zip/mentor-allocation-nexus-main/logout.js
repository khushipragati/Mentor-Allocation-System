
document.addEventListener('DOMContentLoaded', () => {
    // Just to be sure, remove any auth data
    localStorage.removeItem(AUTH_KEY);
});
