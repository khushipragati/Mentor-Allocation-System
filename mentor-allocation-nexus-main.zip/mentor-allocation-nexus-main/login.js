
document.addEventListener('DOMContentLoaded', () => {
    // Redirect to home if already logged in
    if (isLoggedIn()) {
        window.location.href = 'index.html';
        return;
    }
    
    const loginForm = document.getElementById('login-form');
    
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Get form values
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const userType = document.getElementById('userType').value;
        
        // Clear any previous error messages
        const existingError = document.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
        
        // Attempt login
        const result = login(username, password, userType);
        
        if (result.success) {
            window.location.href = 'index.html';
        } else {
            // Display error message
            const errorMessage = document.createElement('div');
            errorMessage.className = 'error-message';
            errorMessage.textContent = result.message;
            loginForm.appendChild(errorMessage);
        }
    });
});
