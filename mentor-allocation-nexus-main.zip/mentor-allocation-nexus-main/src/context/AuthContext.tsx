
import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { toast } from "sonner";

type UserRole = "admin" | "student" | null;

interface AuthContextType {
  isAuthenticated: boolean;
  userRole: UserRole;
  username: string | null;
  login: (username: string, password: string, role: UserRole) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

// Simulated user database
const USERS = [
  { username: "admin", password: "admin123", role: "admin" },
  { username: "student1", password: "student123", role: "student" },
  { username: "student2", password: "student123", role: "student" },
];

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [username, setUsername] = useState<string | null>(null);

  // Check for existing session on component mount
  useEffect(() => {
    const storedUsername = localStorage.getItem("username");
    const storedRole = localStorage.getItem("userRole") as UserRole;
    
    if (storedUsername && storedRole) {
      setIsAuthenticated(true);
      setUsername(storedUsername);
      setUserRole(storedRole);
    }
  }, []);

  const login = (username: string, password: string, role: UserRole): boolean => {
    // Find user in our simulated database
    const user = USERS.find(
      (u) => u.username === username && u.password === password && u.role === role
    );

    if (user) {
      setIsAuthenticated(true);
      setUserRole(role);
      setUsername(username);
      
      // Store session info
      localStorage.setItem("username", username);
      localStorage.setItem("userRole", role as string);
      
      toast.success(`Welcome back, ${username}!`);
      return true;
    } else {
      toast.error("Invalid credentials. Please try again.");
      return false;
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUserRole(null);
    setUsername(null);
    
    // Clear session data
    localStorage.removeItem("username");
    localStorage.removeItem("userRole");
    
    toast.info("You have been logged out successfully.");
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, userRole, username, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
