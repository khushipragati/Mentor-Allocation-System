
import { Link } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";

const Header = () => {
  const { isAuthenticated, logout } = useAuth();

  return (
    <header className="bg-white bg-opacity-90 shadow-md py-4">
      <div className="container mx-auto flex justify-between items-center px-4">
        <h1 className="text-3xl font-bold text-gray-800">
          Mentor Allocation System
        </h1>
        {isAuthenticated && (
          <nav>
            <ul className="flex space-x-6">
              <li>
                <Link to="/" className="text-gray-700 hover:text-mentor transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/mentors" className="text-gray-700 hover:text-mentor transition-colors">
                  Find Mentors
                </Link>
              </li>
              <li>
                <Link to="/group-register" className="text-gray-700 hover:text-mentor transition-colors">
                  Group Register
                </Link>
              </li>
              <li>
                <button 
                  onClick={logout} 
                  className="text-red-500 hover:text-red-700 transition-colors"
                >
                  Logout
                </button>
              </li>
            </ul>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;
