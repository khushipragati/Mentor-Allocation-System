
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useAuth } from "@/context/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const Index = () => {
  const { username, userRole } = useAuth();
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto my-8 px-4">
        <Card className="bg-white bg-opacity-95 shadow-lg rounded-lg overflow-hidden">
          <CardContent className="p-0">
            {/* Hero Section */}
            <section className="text-center p-8 border-b border-gray-200">
              <h2 className="text-4xl font-bold text-gray-800 mb-4">
                Welcome to the Mentor Allocation System
              </h2>
              <p className="text-gray-600 mb-6">
                Find the perfect mentor to guide your projects!
              </p>
              <div className="mt-6 flex justify-center">
                <img
                  src="https://www.schudio.com/wp-content/uploads/2024/08/welcome-page-blog-header.jpg"
                  alt="Mentorship"
                  className="rounded-lg shadow-md max-w-full h-auto"
                  style={{ maxHeight: "300px" }}
                />
              </div>
            </section>

            {/* User Dashboard Section */}
            <section className="p-8">
              <div className="bg-gray-50 rounded-lg p-6 shadow-inner">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">
                  Your Dashboard
                </h3>
                <p className="mb-4">
                  Hello, <span className="font-semibold">{username}</span>! You are logged in as: <span className="font-semibold capitalize">{userRole}</span>
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  <div className="bg-white p-6 rounded-lg shadow">
                    <h4 className="text-xl font-semibold text-mentor mb-3">Quick Actions</h4>
                    <div className="space-y-3">
                      <Link to="/mentors">
                        <Button className="w-full justify-start">
                          <span className="mr-2">🔍</span> Find Mentors
                        </Button>
                      </Link>
                      <Link to="/group-register">
                        <Button variant="outline" className="w-full justify-start">
                          <span className="mr-2">👥</span> Register Group
                        </Button>
                      </Link>
                    </div>
                  </div>
                  
                  <div className="bg-white p-6 rounded-lg shadow">
                    <h4 className="text-xl font-semibold text-mentor mb-3">System Status</h4>
                    <ul className="space-y-2">
                      <li className="flex items-center">
                        <span className="h-3 w-3 bg-green-500 rounded-full mr-2"></span>
                        <span>Mentor Allocation: <span className="font-medium">Active</span></span>
                      </li>
                      <li className="flex items-center">
                        <span className="h-3 w-3 bg-green-500 rounded-full mr-2"></span>
                        <span>Group Registration: <span className="font-medium">Open</span></span>
                      </li>
                      <li className="flex items-center">
                        <span className="h-3 w-3 bg-yellow-500 rounded-full mr-2"></span>
                        <span>Project Submissions: <span className="font-medium">Closing Soon</span></span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
