
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";

const mentors = [
  {
    id: 1,
    name: "Dr. Jane Smith",
    expertise: "Machine Learning, Data Science",
    availability: "Full",
    rating: 4.8,
  },
  {
    id: 2,
    name: "Prof. Michael Johnson",
    expertise: "Software Architecture, Cloud Computing",
    availability: "Limited",
    rating: 4.6,
  },
  {
    id: 3,
    name: "Dr. Sarah Williams",
    expertise: "Web Development, UI/UX",
    availability: "Available",
    rating: 4.9,
  },
  {
    id: 4,
    name: "Prof. David Lee",
    expertise: "Cybersecurity, Network Systems",
    availability: "Full",
    rating: 4.7,
  },
];

const Mentors = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto my-8 px-4">
        <Card className="bg-white bg-opacity-95 shadow-lg rounded-lg overflow-hidden">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Find Mentors</h2>
            
            <div className="overflow-x-auto">
              <table className="w-full bg-white">
                <thead>
                  <tr className="bg-gray-100 text-left">
                    <th className="p-4 font-semibold">Name</th>
                    <th className="p-4 font-semibold">Expertise</th>
                    <th className="p-4 font-semibold">Availability</th>
                    <th className="p-4 font-semibold">Rating</th>
                    <th className="p-4 font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mentors.map((mentor) => (
                    <tr key={mentor.id} className="border-b hover:bg-gray-50">
                      <td className="p-4">{mentor.name}</td>
                      <td className="p-4">{mentor.expertise}</td>
                      <td className="p-4">
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-semibold ${
                            mentor.availability === "Available"
                              ? "bg-green-100 text-green-800"
                              : mentor.availability === "Limited"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-red-100 text-red-800"
                          }`}
                        >
                          {mentor.availability}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center">
                          <span className="mr-2">{mentor.rating}</span>
                          <span className="text-yellow-500">★</span>
                        </div>
                      </td>
                      <td className="p-4">
                        <button className="btn-primary text-sm">Request</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default Mentors;
