
import LoginForm from "@/components/LoginForm";
import Footer from "@/components/Footer";

const Login = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-grow flex justify-center items-center p-4 relative">
        <div className="absolute inset-0 bg-center bg-cover opacity-50"
             style={{ backgroundImage: 'url("https://storage.googleapis.com/a1aa/image/aHe3fxLejBEfBR17A6jmh0q0Dxa5hfMTPkY6ME5eil3ekvt9JA.jpg")' }}>
        </div>
        <LoginForm />
      </main>
      <Footer />
    </div>
  );
};

export default Login;
