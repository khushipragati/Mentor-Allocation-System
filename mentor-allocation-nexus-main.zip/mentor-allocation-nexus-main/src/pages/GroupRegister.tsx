
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { toast } from "sonner";

const GroupRegister = () => {
  const [groupName, setGroupName] = useState("");
  const [projectTopic, setProjectTopic] = useState("");
  const [preferredMentor, setPreferredMentor] = useState("");
  const [members, setMembers] = useState(["", "", ""]);

  const handleMemberChange = (index: number, value: string) => {
    const newMembers = [...members];
    newMembers[index] = value;
    setMembers(newMembers);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if all fields are filled
    if (!groupName || !projectTopic || !preferredMentor || members.some(member => !member)) {
      toast.error("Please fill in all required fields.");
      return;
    }
    
    // Simulate successful registration
    toast.success("Group registration successful! Your mentor will be assigned soon.");
    
    // Reset form
    setGroupName("");
    setProjectTopic("");
    setPreferredMentor("");
    setMembers(["", "", ""]);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto my-8 px-4">
        <Card className="bg-white bg-opacity-95 shadow-lg rounded-lg overflow-hidden">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Group Registration</h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="groupName">Group Name</Label>
                  <Input
                    id="groupName"
                    value={groupName}
                    onChange={(e) => setGroupName(e.target.value)}
                    placeholder="Enter your group name"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="projectTopic">Project Topic</Label>
                  <Input
                    id="projectTopic"
                    value={projectTopic}
                    onChange={(e) => setProjectTopic(e.target.value)}
                    placeholder="Enter your project topic"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="preferredMentor">Preferred Mentor</Label>
                <Select
                  value={preferredMentor}
                  onValueChange={setPreferredMentor}
                >
                  <SelectTrigger id="preferredMentor">
                    <SelectValue placeholder="Select a preferred mentor" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dr-jane-smith">Dr. Jane Smith</SelectItem>
                    <SelectItem value="prof-michael-johnson">Prof. Michael Johnson</SelectItem>
                    <SelectItem value="dr-sarah-williams">Dr. Sarah Williams</SelectItem>
                    <SelectItem value="prof-david-lee">Prof. David Lee</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-xl font-semibold">Group Members</h3>
                
                {members.map((member, index) => (
                  <div key={index} className="space-y-2">
                    <Label htmlFor={`member-${index}`}>Member {index + 1}</Label>
                    <Input
                      id={`member-${index}`}
                      value={member}
                      onChange={(e) => handleMemberChange(index, e.target.value)}
                      placeholder={`Enter member ${index + 1} name`}
                      required
                    />
                  </div>
                ))}
              </div>
              
              <Button type="submit" className="bg-mentor hover:bg-mentor-dark">
                Register Group
              </Button>
            </form>
          </CardContent>
        </Card>
      </main>
      
      <Footer />
    </div>
  );
};

export default GroupRegister;
