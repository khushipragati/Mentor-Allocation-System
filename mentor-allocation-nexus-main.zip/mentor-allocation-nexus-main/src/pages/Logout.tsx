
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Footer from "@/components/Footer";

const Logout = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  
  useEffect(() => {
    logout();
  }, [logout]);
  
  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-grow flex justify-center items-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Successfully Logged Out</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="mb-6">You have been successfully logged out of your account.</p>
            <Button 
              onClick={() => navigate("/login")}
              className="bg-mentor hover:bg-mentor-dark"
            >
              Log In Again
            </Button>
          </CardContent>
        </Card>
      </main>
      <Footer />
    </div>
  );
};

export default Logout;
