
document.addEventListener('DOMContentLoaded', () => {
    // Load mock mentors data
    loadMentors();
    
    // Set up search functionality
    const searchInput = document.getElementById('mentor-search');
    searchInput.addEventListener('input', () => {
        filterMentors(searchInput.value.toLowerCase());
    });
});

// Mock mentors data
const mentorsData = [
    {
        id: 1,
        name: 'Prof. Sarah Johnson',
        specialty: 'Machine Learning',
        availability: 'Available',
        image: 'https://randomuser.me/api/portraits/women/44.jpg'
    },
    {
        id: 2,
        name: 'Dr. Michael Chen',
        specialty: 'Web Development',
        availability: 'Limited Availability',
        image: 'https://randomuser.me/api/portraits/men/32.jpg'
    },
    {
        id: 3,
        name: 'Prof. Emily Davis',
        specialty: 'Data Science',
        availability: 'Available',
        image: 'https://randomuser.me/api/portraits/women/68.jpg'
    },
    {
        id: 4,
        name: 'Dr. James Wilson',
        specialty: 'Mobile Development',
        availability: 'Not Available',
        image: 'https://randomuser.me/api/portraits/men/52.jpg'
    },
    {
        id: 5,
        name: 'Prof. Olivia Martinez',
        specialty: 'UI/UX Design',
        availability: 'Available',
        image: 'https://randomuser.me/api/portraits/women/29.jpg'
    },
    {
        id: 6,
        name: 'Dr. David Thompson',
        specialty: 'Cybersecurity',
        availability: 'Limited Availability',
        image: 'https://randomuser.me/api/portraits/men/41.jpg'
    }
];

function loadMentors() {
    const container = document.getElementById('mentors-container');
    
    // Clear loading text
    container.innerHTML = '';
    
    // Display mentors
    mentorsData.forEach(mentor => {
        const mentorCard = createMentorCard(mentor);
        container.appendChild(mentorCard);
    });
}

function createMentorCard(mentor) {
    const card = document.createElement('div');
    card.className = 'mentor-card';
    card.dataset.id = mentor.id;
    
    // Create card HTML
    card.innerHTML = `
        <img src="${mentor.image}" alt="${mentor.name}" style="width: 100%; height: 180px; object-fit: cover;">
        <div class="mentor-info">
            <h3 class="mentor-name">${mentor.name}</h3>
            <p class="mentor-specialty">${mentor.specialty}</p>
            <p class="mentor-availability">
                ${getAvailabilityHTML(mentor.availability)}
            </p>
            <button class="btn-primary request-mentor">Request Mentor</button>
        </div>
    `;
    
    // Add event listener for the request button
    const requestButton = card.querySelector('.request-mentor');
    requestButton.addEventListener('click', () => {
        alert(`Request sent to ${mentor.name}. They will contact you soon!`);
    });
    
    return card;
}

function getAvailabilityHTML(availability) {
    if (availability === 'Available') {
        return `<span style="color: var(--success);">● ${availability}</span>`;
    } else if (availability === 'Limited Availability') {
        return `<span style="color: orange;">● ${availability}</span>`;
    } else {
        return `<span style="color: var(--error);">● ${availability}</span>`;
    }
}

function filterMentors(searchText) {
    const container = document.getElementById('mentors-container');
    const cards = container.querySelectorAll('.mentor-card');
    
    cards.forEach(card => {
        const name = card.querySelector('.mentor-name').textContent.toLowerCase();
        const specialty = card.querySelector('.mentor-specialty').textContent.toLowerCase();
        
        if (name.includes(searchText) || specialty.includes(searchText)) {
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
}
