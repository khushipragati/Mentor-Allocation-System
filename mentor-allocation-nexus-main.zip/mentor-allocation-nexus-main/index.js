
document.addEventListener('DOMContentLoaded', () => {
    // Get current user
    const user = getCurrentUser();
    
    // Display user-specific content if needed
    if (user) {
        // This could be expanded to show different content for different users
        console.log(`Logged in as ${user.userType}: ${user.username}`);
    }
    
    // Load mock group members data
    loadGroupMembers();
});

function loadGroupMembers() {
    const container = document.getElementById('group-members-container');
    
    // Mock data - in a real app, this would come from a server request
    const groupMembers = [
        { id: 1, name: 'John Doe', role: 'Team Lead', email: 'john@example.com' },
        { id: 2, name: 'Jane Smith', role: 'Developer', email: 'jane@example.com' },
        { id: 3, name: 'Alex Johnson', role: 'Designer', email: 'alex@example.com' },
        { id: 4, name: 'Sam Brown', role: 'Tester', email: 'sam@example.com' }
    ];
    
    // Clear loading text
    container.innerHTML = '';
    
    if (groupMembers.length === 0) {
        container.innerHTML = '<p>No group members found. Register a group first.</p>';
        return;
    }
    
    // Create table
    const table = document.createElement('table');
    table.className = 'members-table';
    
    // Add table header
    const thead = document.createElement('thead');
    thead.innerHTML = `
        <tr>
            <th>Name</th>
            <th>Role</th>
            <th>Email</th>
        </tr>
    `;
    table.appendChild(thead);
    
    // Add table body
    const tbody = document.createElement('tbody');
    groupMembers.forEach(member => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${member.name}</td>
            <td>${member.role}</td>
            <td>${member.email}</td>
        `;
        tbody.appendChild(row);
    });
    table.appendChild(tbody);
    
    container.appendChild(table);
}
