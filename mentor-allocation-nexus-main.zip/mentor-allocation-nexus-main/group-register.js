
document.addEventListener('DOMContentLoaded', () => {
    // Set up the "Add Member" button
    const addMemberButton = document.getElementById('add-member');
    addMemberButton.addEventListener('click', addNewMemberField);
    
    // Set up form submission
    const registrationForm = document.getElementById('group-registration-form');
    registrationForm.addEventListener('submit', handleRegistrationSubmit);
});

function addNewMemberField() {
    const container = document.getElementById('members-container');
    
    // Create new member input group
    const memberInput = document.createElement('div');
    memberInput.className = 'member-input';
    
    // Create inputs
    memberInput.innerHTML = `
        <input type="text" class="member-name" placeholder="Member name">
        <input type="email" class="member-email" placeholder="Member email">
        <button type="button" class="remove-member">✕</button>
    `;
    
    // Add event listener to remove button
    const removeButton = memberInput.querySelector('.remove-member');
    removeButton.addEventListener('click', () => {
        container.removeChild(memberInput);
    });
    
    // Add to container
    container.appendChild(memberInput);
}

function handleRegistrationSubmit(event) {
    event.preventDefault();
    
    // Get form values
    const groupName = document.getElementById('group-name').value;
    const projectDescription = document.getElementById('project-description').value;
    
    // Get members
    const memberInputs = document.querySelectorAll('.member-input');
    const members = [];
    
    memberInputs.forEach(input => {
        const name = input.querySelector('.member-name').value;
        const email = input.querySelector('.member-email').value;
        
        if (name && email) {
            members.push({ name, email });
        }
    });
    
    // Validate
    if (!groupName) {
        alert('Please enter a group name');
        return;
    }
    
    if (members.length === 0) {
        alert('Please add at least one group member');
        return;
    }
    
    // In a real app, this would be sent to a server
    console.log('Group registration:', {
        groupName,
        projectDescription,
        members
    });
    
    // Show success message
    alert('Group registered successfully!');
    
    // Reset the form
    event.target.reset();
    
    // Reset member fields
    document.getElementById('members-container').innerHTML = `
        <div class="member-input">
            <input type="text" class="member-name" placeholder="Member name">
            <input type="email" class="member-email" placeholder="Member email">
        </div>
    `;
}
