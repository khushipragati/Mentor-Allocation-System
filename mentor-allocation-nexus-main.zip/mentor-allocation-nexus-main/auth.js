
// Authentication handling
const AUTH_KEY = 'mentor_allocation_auth';

// Check if user is logged in
function isLoggedIn() {
    const authData = localStorage.getItem(AUTH_KEY);
    return authData !== null;
}

// Get current user data
function getCurrentUser() {
    const authData = localStorage.getItem(AUTH_KEY);
    return authData ? JSON.parse(authData) : null;
}

// Login function
function login(username, password, userType) {
    // Simple validation
    if (!username || !password || !userType) {
        return {
            success: false,
            message: 'All fields are required'
        };
    }
    
    // In a real app, you would authenticate against a server
    // This is a simple mock for demonstration
    let isValid = false;
    
    if (userType === 'admin' && username === 'admin' && password === 'admin123') {
        isValid = true;
    } else if (userType === 'student' && username === 'student' && password === 'student123') {
        isValid = true;
    }
    
    if (isValid) {
        // Store auth data in local storage
        const userData = {
            username,
            userType,
            loginTime: new Date().toISOString()
        };
        localStorage.setItem(AUTH_KEY, JSON.stringify(userData));
        return {
            success: true,
            message: 'Login successful'
        };
    } else {
        return {
            success: false,
            message: 'Invalid credentials'
        };
    }
}

// Logout function
function logout() {
    localStorage.removeItem(AUTH_KEY);
    window.location.href = 'logout.html';
}

// Check authentication on page load (except for login and logout pages)
function checkAuth() {
    const currentPage = window.location.pathname.split('/').pop();
    
    if (currentPage !== 'login.html' && currentPage !== 'logout.html') {
        if (!isLoggedIn()) {
            window.location.href = 'login.html';
        }
    }
}

// Initialize auth check
document.addEventListener('DOMContentLoaded', () => {
    // Set current year in footer
    const yearElements = document.querySelectorAll('#current-year');
    yearElements.forEach(el => {
        el.textContent = new Date().getFullYear();
    });
    
    // Check auth on non-login/logout pages
    checkAuth();
    
    // Add logout functionality to logout links
    const logoutLinks = document.querySelectorAll('.logout');
    logoutLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    });
});
